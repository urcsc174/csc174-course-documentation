<?php
// connect to the database
include('config.php');

// check if the 'counter' variable is set in URL, and check that it is valcounter
if (isset($_GET['counter']) && is_numeric($_GET['counter'])) {
	// get counter value
	$counter = $_GET['counter'];

	// delete the entry
	$result = mysqli_query($connection, "DELETE FROM contacts WHERE counter=$counter");

	// redirect back to the homepage to see the results
	header("Location: read.php");

} else {
	// if counter isn't set, or isn't valid, redirect back to homepage
	header("Location: read.php");
}
?>