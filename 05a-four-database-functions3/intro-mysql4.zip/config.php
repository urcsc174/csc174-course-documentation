<?php
    $dbhost = "localhost";
    $dbuser = "lab03";
    $dbpass = "coffee";
    $dbname = "lab03";
    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
?>