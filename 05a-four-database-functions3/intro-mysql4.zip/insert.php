<?php
include('renderform.php');

// connect to the database
include('config.php');

// check if the form has been submitted. If it has, start to process the form and save it to the database
if (isset($_POST['submit'])) {
	// get form data, making sure it is valcounter
	$firstName = mysqli_real_escape_string($connection, htmlspecialchars($_POST['firstName']));
	$lastName = mysqli_real_escape_string($connection, htmlspecialchars($_POST['lastName']));
	$email = mysqli_real_escape_string($connection, htmlspecialchars($_POST['email']));

	// check to make sure both naem fields are entered
	if ($firstName == '' || $lastName == '') {
		// generate error message
		$error = 'ERROR: Please fill in the required fields!';

		// if either field is blank, display the form again
		renderForm($counter, $firstName, $lastName, $email, $error);

	} else {
		// save the data to the database
		$result = mysqli_query($connection, "INSERT INTO contacts (firstName, lastName, email) VALUES ('$firstName','$lastName','$email')");

		if ($result) {
			echo "Success! - the query seemed to work! (At least it didn't error-out.)";
		} else {
			die("Database query failed.");
		}

		// once saved, redirect back to the view page
		header("Location: read.php");
	}
} else {
	// if the form hasn't been submitted, display the form
	renderForm('','','','','');
}
?>