<html>
<head>
	<meta charset="utf-8">
	<title>Server Info</title>
	<style>
		body {
			margin: 0 auto;
			width: 90%;
			max-width: 1200px;
			background-color: lightyellow;
			font-family: Arial, sans-serif;
			color: #333333;
		}
		h1, h2 { font-size: larger; }
		nav {
			position:fixed;
			top: 10px;
			right: 10px;
			background-color: lightyellow;
		}
	</style>
</head>
<body>

<nav><a href=".">Back</a></nav>

<h1>Apache</h1>
<?php echo $_SERVER['SERVER_SOFTWARE']; ?><br><br>

Server name: <samp><?php echo $_SERVER['SERVER_NAME']; ?></samp><br>
Document root: <samp><?php echo $_SERVER['DOCUMENT_ROOT']; ?></samp><br>

<hr>

<h1>PHP</h1>
<?php echo 'Current PHP version: ' . phpversion(); ?>

<hr>

<h1>MySQL</h1>
<?php
#$mysqli = new mysqli(localhost, dbusername, dbuserpass [, database]);
$mysqli = new mysqli('localhost', 'root', 'root', '');

if ($mysqli->connect_error) {
    die('Connect Error (' . $mysqli->connect_errno . ') '
            . $mysqli->connect_error);
}
echo '<p>Connection OK '. $mysqli->host_info.'<br>';
echo 'Server '.$mysqli->server_info.'</p>';
$mysqli->close();
?>

</body>
</html>