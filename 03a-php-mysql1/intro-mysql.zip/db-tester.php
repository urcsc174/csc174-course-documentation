<?php
$dbhost = $_POST['host'];
$dbuser = $_POST['user'];
$dbpass = $_POST['pass'];
$dbname = $_POST['name'];
?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Database Tester</title>
	<style>
		body {
			margin: 0 auto;
			width: 90%;
			max-width: 1200px;
			background-color: lightyellow;
			font-family: Arial, sans-serif;
			color: #333333;
		}
		form { 
			padding-bottom: 15px;
			border-bottom: 1px solid #999999;
			margin-bottom: 15px;
		}
		input[type="submit"] { margin-top: 10px; }
		h1, h2 { font-size: larger; }
		div { margin-bottom: 5px; }
		span {
			color: gray;
			font-style: italic;
			font-size:small;
		}
		nav {
			position:fixed;
			top: 10px;
			right: 10px;
			background-color: lightyellow;
		}
	</style>
</head>
<body>

	<h1>Enter the database credentials...</h1>

	<form action="#" method="post">
		<div>
			<label for="host">$dbhost</label>
			<input type="text" name="host" id="host" value="<?php echo (isset($_POST['submit']) ? $dbhost : 'localhost'); ?>">
			<span>server: "localhost" or the IP of the machine</span>
		</div>
		<div>
			<label for="user">$dbuser</label>
			<input type="text" name="user" id="user" value="<?php echo (isset($_POST['submit']) ? $dbuser : 'root'); ?>">
			<span>database username</span>
		</div>
		<div>
			<label for="pass">$dbpass</label>
			<input type="text" name="pass" id="pass" value="<?php echo (isset($_POST['submit']) ? $dbpass : 'root'); ?>">
			<span>database user password</span>
		</div>
		<div>
			<label for="name">$dbname</label>
			<input type="text" name="name" id="name" value="<?php echo (isset($_POST['submit']) ? $dbname : ''); ?>">
			<span>(optional) database name</span>
		</div>
		<div>
			<input type="submit" name="submit" value="Run the test">
		</div>
	</form>

	<main>

<?php
if (isset($_POST['submit']))
{
	$link = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

	/* check connection */
	if (mysqli_connect_errno()) {
	    printf("Connect failed: %s\n", mysqli_connect_error());
	    exit();
	}

	/* check if server is alive */
	if (mysqli_ping($link)) {
	    printf ("The connection is ok!\n");
	} else {
	    printf ("Error: %s\n", mysqli_error($link));
	}
	echo "<h1>Database: ". $dbname . "</h1>\n";
	$databaseResult = $link->query("SHOW TABLES from $dbname");
	while($tableName = mysqli_fetch_row($databaseResult))
	{
	    $table = $tableName[0];
	    echo '<h2>Table: ' ,$table, "</h2>\n";
	    $tableResult = $link->query("SHOW COLUMNS from ".$table.""); 
	    if(mysqli_num_rows($tableResult))
	    {
	        echo "<table border>\n<caption>Table Structure</caption>\n<tr>\n<th>Field</th>\n<th>Type</th>\n<th>Null</th>\n<th>Key</th>\n<th>Default</th>\n<th>Extra</th>\n</tr>\n";
	        while($row = mysqli_fetch_row($tableResult))
	        {
	            echo "<tr>";
	            foreach ($row as $key=>$value)
	            {
	                echo "<td>",$value, "</td>\n";
	            }
	            echo "</tr>\n";
	        }
	        echo "</table>\n";
	    }

		$result = mysqli_query($link,"SELECT * FROM $table");
		$all_property = array();  //declare an array for saving property

		//showing property
		echo "<br>\n<table border>\n<caption>Entered Data</caption>\n<tr>\n";
		while ($property = mysqli_fetch_field($result)) {
		    echo "<th>" . $property->name . "</th>\n";  //get field name for header
		    array_push($all_property, $property->name);  //save those to array
		}
		echo "</tr>\n";

		//showing all data
		while ($row = mysqli_fetch_array($result)) {
		    echo "<tr>\n";
		    foreach ($all_property as $item) {
		        echo "<td>" . $row[$item] . "</td>\n"; //get items using property value
		    }
		    echo "</tr>\n";
		}
		echo "</table>\n";
	}

	/* close connection */
	mysqli_free_result($result);
	mysqli_close($link);

}
?>

	</main>

<nav><a href=".">Back</a></nav>

</body>
</html>